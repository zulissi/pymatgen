#!/usr/bin/env python

from pymatgen.analysis.chemenv.utils.scripts_utils import compute_environments, welcome, thankyou
from pymatgen.analysis.chemenv.utils.chemenv_config import ChemEnvConfig
from argparse import ArgumentParser

import logging


__author__ = 'waroquiers'


def run_script():
    m_description = 'Welcome to the Chemical Environment Package.'
    parser = ArgumentParser(description=m_description)
    setup_help = 'Used to setup the configuration of the package '
    setup_help += '(MaterialsProject access, ICSD database access, package options, ...)'
    parser.add_argument('-s', '--setup', help=setup_help, action='store_true')
    parser.add_argument('-m', '--message-level', help='Message level (DEBUG, INFO, WARNING, ERROR or CRITICAL - '
                                                      'default : WARNING)',
                        default='WARNING')
    args = parser.parse_args()
    if args.setup:
        chemenv_config = ChemEnvConfig.auto_load()
        chemenv_config.setup()
        print('\n Setup completed')
    else:
        chemenv_config = ChemEnvConfig.auto_load()
    welcome(chemenv_config)
    logging.basicConfig(format='%(levelname)s:%(module)s:%(funcName)s:%(message)s', level=args.message_level)
    compute_environments(chemenv_config)
    thankyou()


if __name__ == '__main__':
    run_script()