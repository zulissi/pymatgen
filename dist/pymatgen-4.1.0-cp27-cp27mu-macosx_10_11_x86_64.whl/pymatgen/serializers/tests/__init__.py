"""
The serializers package implements various tools to encode and decode pymatgen
objects from commonly used data formats such as json.
"""
