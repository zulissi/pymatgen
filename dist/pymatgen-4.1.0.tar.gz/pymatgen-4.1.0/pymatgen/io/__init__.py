# coding: utf-8
# Copyright (c) Pymatgen Development Team.
# Distributed under the terms of the MIT License.

"""
This package provides the packages and modules to perform IO from various
input file formats and pymatgen objects.
"""
