from __future__ import unicode_literals
"""
Test suite for defect code in pymatgen
"""
