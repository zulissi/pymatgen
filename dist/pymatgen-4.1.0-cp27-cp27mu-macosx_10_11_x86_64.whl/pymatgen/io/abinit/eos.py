# coding: utf-8
# Copyright (c) Pymatgen Development Team.
# Distributed under the terms of the MIT License.
#!/usr/bin/env python

from __future__ import division, unicode_literals

import warnings
warnings.warn("pymatgen.io.abinit.eos has been moved pymatgen.analysis.eos "
              "This stub will be removed in pymatgen 4.0.", DeprecationWarning)

from pymatgen.analysis.eos import *
